import { useQuery } from "@tanstack/react-query";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Search,
  SlidersHorizontal,
  ShoppingBag,
  Sparkles,
  X,
} from "lucide-react";

import { getNFTs } from "../services/nfts";
import type { CatalogSearch } from "../router";

const defaultFilters: CatalogSearch = {
  search: "",
  category: "all",
  sort: "default",
  page: 1,
};

const inputClass =
  "w-full rounded-md border border-[#493026] bg-[#1a100d] px-3 py-2.5 text-sm text-[#f5dfc4] outline-none placeholder:text-[#876c59] focus:border-[#d18a4c]";

export default function Home() {
  const navigate = useNavigate({ from: "/" });
  const filters = useSearch({ from: "/" });

  function updateFilters(changes: Partial<CatalogSearch>) {
    void navigate({
      search: (previous) => ({
        ...previous,
        ...changes,
        page: changes.page ?? 1,
      }),
    });
  }

  function clearFilters() {
    void navigate({
      search: defaultFilters,
    });
  }

  const { data, isPending, isError, refetch, isFetching } = useQuery({
    queryKey: ["nfts", filters],
    queryFn: ({ signal }) => getNFTs(filters, signal),
  });

  const hasActiveFilters =
    filters.search !== "" ||
    filters.category !== "all" ||
    filters.sort !== "default";

  const featured = data?.items[0];

  return (
    <main className="min-h-screen bg-[#120b09] text-[#f5e5cf]">
      <div className="mx-auto max-w-7xl px-4 pb-16 pt-8 sm:px-6 lg:px-8">
        {/* BANNER PRINCIPAL */}
        <section className="relative overflow-hidden rounded-lg border border-[#382219] bg-[#1a100d]">
          <div className="grid min-h-[290px] items-center gap-8 p-6 sm:p-10 md:grid-cols-[1.2fr_0.8fr] lg:p-12">
            <div className="relative z-10">
              <p className="mb-4 text-[10px] font-semibold uppercase tracking-[0.28em] text-[#d59a66]">
                Marketplace de NFTs
              </p>

              <h1 className="max-w-xl text-3xl font-black uppercase leading-[1.1] tracking-tight text-[#fff0d9] sm:text-4xl lg:text-5xl">
                Seja dono do futuro
                <span className="block text-[#d68c4b]">da arte digital</span>
              </h1>

              <p className="mt-5 max-w-md text-sm leading-6 text-[#bda18a]">
                Explore colecionáveis digitais exclusivos e encontre a próxima
                peça da sua coleção.
              </p>

              <button
                type="button"
                onClick={() => {
                  document
                    .getElementById("catalogo")
                    ?.scrollIntoView({ behavior: "smooth" });
                }}
                className="mt-7 inline-flex cursor-pointer items-center gap-2 rounded-sm bg-[#d58a49] px-5 py-2.5 text-xs font-bold text-[#1b100b] transition hover:bg-[#f0a865]"
              >
                Explorar NFTs
                <ArrowRight size={15} />
              </button>
            </div>

            {/* NFT EM DESTAQUE */}
            <div className="relative flex min-h-[220px] items-center justify-center">
              <div className="absolute h-52 w-52 rounded-full bg-[#a65b2a]/15 blur-3xl" />

              {featured ? (
                <Link
                  to="/nft/$nftId"
                  params={{ nftId: featured.id }}
                  className="relative block w-48 rotate-2 overflow-hidden rounded-md border-4 border-[#60402b] bg-[#392419] shadow-2xl shadow-black/40 transition hover:rotate-0 sm:w-56"
                >
                  <img
                    src={featured.image}
                    alt={featured.name}
                    className="aspect-square w-full object-cover"
                  />
                </Link>
              ) : (
                <div className="relative flex h-48 w-48 items-center justify-center rounded-md border border-[#60402b] bg-[#291912]">
                  <Sparkles className="h-16 w-16 text-[#d58a49]" />
                </div>
              )}
            </div>
          </div>
        </section>

        {/* CATÁLOGO */}
        <section id="catalogo" className="scroll-mt-24 pt-12">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#d58a49]">
                Coleção digital
              </p>

              <h2 className="mt-2 text-2xl font-bold text-[#fff0d9]">
                Explore NFTs
              </h2>
            </div>

            <Link
              to="/cart"
              className="inline-flex items-center gap-2 rounded-sm border border-[#6c432d] px-4 py-2 text-xs font-semibold text-[#e7ae76] hover:bg-[#2a1a13]"
            >
              <ShoppingBag size={15} />
              Ver carrinho
              <ArrowUpRight size={13} />
            </Link>
          </div>

          <div className="grid gap-7 lg:grid-cols-[215px_minmax(0,1fr)]">
            {/* FILTROS LATERAIS */}
            <aside className="h-fit rounded-md border border-[#38251b] bg-[#20140f] p-4">
              <div className="mb-5 flex items-center justify-between gap-2">
                <h3 className="flex items-center gap-2 text-sm font-bold">
                  <SlidersHorizontal size={16} className="text-[#d58a49]" />
                  Filtros
                </h3>

                {hasActiveFilters && (
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="flex cursor-pointer items-center gap-1 text-xs text-[#dfa16b] hover:text-[#ffd2a0]"
                  >
                    <X size={13} />
                    Limpar
                  </button>
                )}
              </div>

              <div className="space-y-5">
                {/* BUSCA */}
                <div>
                  <label
                    htmlFor="search"
                    className="mb-2 block text-xs font-semibold text-[#d6b99c]"
                  >
                    Buscar NFT
                  </label>

                  <div className="relative">
                    <Search
                      size={15}
                      className="absolute left-3 top-3 text-[#95715a]"
                    />

                    <input
                      id="search"
                      type="search"
                      placeholder="Nome do NFT..."
                      value={filters.search}
                      onChange={(event) =>
                        updateFilters({
                          search: event.target.value,
                        })
                      }
                      className={`${inputClass} pl-9`}
                    />
                  </div>
                </div>

                {/* CATEGORIA */}
                <div>
                  <label
                    htmlFor="category"
                    className="mb-2 block text-xs font-semibold text-[#d6b99c]"
                  >
                    Categoria
                  </label>

                  <select
                    id="category"
                    value={filters.category}
                    onChange={(event) =>
                      updateFilters({
                        category: event.target.value,
                      })
                    }
                    className={inputClass}
                  >
                    <option value="all">Todas as categorias</option>
                    <option value="Art">Arte</option>
                    <option value="Gaming">Gaming</option>
                  </select>
                </div>

                {/* ORDENAÇÃO */}
                <div>
                  <label
                    htmlFor="sort"
                    className="mb-2 block text-xs font-semibold text-[#d6b99c]"
                  >
                    Ordenar por
                  </label>

                  <select
                    id="sort"
                    value={filters.sort}
                    onChange={(event) =>
                      updateFilters({
                        sort: event.target.value,
                      })
                    }
                    className={inputClass}
                  >
                    <option value="default">Padrão</option>
                    <option value="price-asc">Menor preço</option>
                    <option value="price-desc">Maior preço</option>
                  </select>
                </div>
              </div>
            </aside>

            {/* RESULTADOS */}
            <div className="min-w-0">
              <div className="mb-4 flex min-h-6 items-center justify-between gap-2">
                <p className="text-xs text-[#a88b73]">
                  {data
                    ? `${data.total} NFT${
                        data.total === 1 ? "" : "s"
                      } encontrado${data.total === 1 ? "" : "s"}`
                    : isPending
                      ? "Carregando coleção..."
                      : ""}
                </p>

                {isFetching && !isPending && (
                  <span role="status" className="text-xs text-[#d58a49]">
                    Atualizando...
                  </span>
                )}
              </div>

              {/* CARREGAMENTO */}
              {isPending && (
                <div
                  role="status"
                  className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4"
                >
                  {Array.from({ length: 8 }).map((_, index) => (
                    <div
                      key={index}
                      className="animate-pulse overflow-hidden rounded-md border border-[#38251b] bg-[#20140f]"
                    >
                      <div className="aspect-square bg-[#38251b]" />

                      <div className="space-y-2 p-3">
                        <div className="h-3 w-1/2 rounded bg-[#38251b]" />
                        <div className="h-4 w-3/4 rounded bg-[#38251b]" />
                      </div>
                    </div>
                  ))}

                  <span className="sr-only">Carregando NFTs...</span>
                </div>
              )}

              {/* ERRO */}
              {isError && (
                <div
                  role="alert"
                  className="rounded-md border border-red-900 bg-red-950/30 p-5 text-sm text-red-200"
                >
                  Não foi possível carregar os NFTs.
                  <button
                    type="button"
                    onClick={() => void refetch()}
                    className="ml-3 cursor-pointer font-bold underline"
                  >
                    Tentar novamente
                  </button>
                </div>
              )}

              {/* SEM RESULTADOS */}
              {data && data.items.length === 0 && (
                <div className="rounded-md border border-dashed border-[#60402b] bg-[#20140f] p-10 text-center">
                  <Search className="mx-auto text-[#b77a49]" size={32} />

                  <h3 className="mt-4 font-bold">Nenhum NFT encontrado</h3>

                  <p className="mt-2 text-sm text-[#a88b73]">
                    Experimente alterar sua busca ou os filtros.
                  </p>

                  <button
                    type="button"
                    onClick={clearFilters}
                    className="mt-5 cursor-pointer rounded-sm bg-[#d58a49] px-4 py-2 text-xs font-bold text-[#1b100b]"
                  >
                    Limpar filtros
                  </button>
                </div>
              )}

              {/* CARDS DOS NFTS */}
              {data && data.items.length > 0 && (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
                  {data.items.map((nft) => (
                    <Link
                      key={nft.id}
                      to="/nft/$nftId"
                      params={{ nftId: nft.id }}
                      className="group min-w-0 overflow-hidden rounded-md border border-[#38251b] bg-[#21150f] outline-none transition hover:-translate-y-0.5 hover:border-[#bb7842] focus-visible:ring-2 focus-visible:ring-[#d58a49]"
                    >
                      <div className="relative aspect-square overflow-hidden bg-[#392419]">
                        <img
                          src={nft.image}
                          alt={nft.name}
                          loading="lazy"
                          decoding="async"
                          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />

                        {nft.available <= 0 && (
                          <span className="absolute left-2 top-2 rounded-sm bg-[#1b100b]/90 px-2 py-1 text-[10px] text-[#e7b28b]">
                            Esgotado
                          </span>
                        )}
                      </div>

                      <div className="p-3">
                        <p className="truncate text-[10px] text-[#bd916e]">
                          {nft.creator}
                        </p>

                        <h3 className="mt-1 truncate text-xs font-bold text-[#f6e5ce] sm:text-sm">
                          {nft.name}
                        </h3>

                        <div className="mt-3 flex items-end justify-between gap-1 border-t border-[#3c281d] pt-2">
                          <div>
                            <p className="text-[10px] text-[#94765f]">Preço</p>

                            <p className="text-sm font-extrabold text-[#e2a063]">
                              {nft.price}{" "}
                              <span className="text-[10px]">ETH</span>
                            </p>
                          </div>

                          <ArrowUpRight
                            size={15}
                            className="mb-1 shrink-0 text-[#bd916e]"
                          />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}

              {/* PAGINAÇÃO */}
              {data && data.totalPages > 1 && (
                <nav
                  aria-label="Paginação do catálogo"
                  className="mt-8 flex flex-wrap items-center justify-center gap-3"
                >
                  <button
                    type="button"
                    disabled={filters.page <= 1}
                    onClick={() =>
                      updateFilters({
                        page: filters.page - 1,
                      })
                    }
                    className="inline-flex cursor-pointer items-center gap-1 rounded-sm border border-[#60402b] px-3 py-2 text-xs text-[#e4b284] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <ArrowLeft size={14} />
                    Anterior
                  </button>

                  <span className="text-xs text-[#bda18a]">
                    Página {filters.page} de {data.totalPages}
                  </span>

                  <button
                    type="button"
                    disabled={filters.page >= data.totalPages}
                    onClick={() =>
                      updateFilters({
                        page: filters.page + 1,
                      })
                    }
                    className="inline-flex cursor-pointer items-center gap-1 rounded-sm bg-[#d58a49] px-3 py-2 text-xs font-bold text-[#1b100b] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Próxima
                    <ArrowRight size={14} />
                  </button>
                </nav>
              )}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
